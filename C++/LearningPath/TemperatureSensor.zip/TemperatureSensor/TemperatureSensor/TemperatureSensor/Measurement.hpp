#ifndef MEASUREMENT_HPP
#define MEASUREMENT_HPP
#include <chrono>

using namespace std;

struct Measurement {
	string timestamp;
	double value;
};

#endif