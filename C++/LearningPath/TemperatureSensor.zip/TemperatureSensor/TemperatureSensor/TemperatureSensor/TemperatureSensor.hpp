#ifndef TEMPERATURE_SENSOR_HPP
#define TEMPERATURE_SENSOR_HPP
#include <vector>
#include "Measurement.hpp"
using namespace std;

class TemperatureSensor {
public:
	TemperatureSensor();
	void addReading(double value);
	double getAverageTemperature();
	double getAverageTemperatureOver(time_t timespan);
	Measurement getMin();
	Measurement getMax();

private:
	vector<Measurement> measurement;
	const int maxNumberOfValues = 10;

};

#endif TEMPERATURE_SENSOR_HPP
