#ifndef LOGGER_HPP
#define LOGGER_HPP

#include <string>
using namespace std;

void LogEvent(const string& level, const string& message);

#endif